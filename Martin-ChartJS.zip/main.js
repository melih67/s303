var ctx = document.getElementById("myChart").getContext("2d");

var chartData = {
  labels: ["2011", "2019", "2020", "2021"],
  datasets: [
    {
      label: "Ensemble",
      data: [439.1, 521.0, 540.0, 470.1],
      backgroundColor: "#428bca",
    },
    {
      label: "Marchandises",
      data: [175.7, 212.8, 202.2, 189.5],
      backgroundColor: "#ff7675",
    },
    {
      label: "Voyageurs: Transport collectif",
      data: [29.5, 28.2, 20.6, 22.8],
      backgroundColor: "#a7a7a7",
    },
    {
      label: "Voyageurs: Transport individuel",
      data: [242.8, 297.7, 290.6, 257.9],
      backgroundColor: "#98df8a",
    },
  ],
};

var myChart = new Chart(ctx, {
  type: "bar",
  data: chartData,
  options: {
    title: {
      text: "Consommation d'énergie des transports",
    },
    scales: {
      yAxes: [
        {
          ticks: {
            beginAtZero: true,
            max: 600,
          },
        },
      ],
    },
  },
});
